#pragma once

#define __BOARDVIEW_H__

#include <math.h>

template< class T, class TBase = CStatic, class TWinTraits = CControlWinTraits >
class ATL_NO_VTABLE CBoardViewImpl : public CWindowImpl< T, TBase, TWinTraits >
{
	typedef class CWindowImpl<T,TBase,TWinTraits> baseClass;
public:
	CFont m_font;
	CBoard& m_board;
	CVisitList& m_visitlist;
	int m_item;

	CBoardViewImpl(CBoard* pb, CVisitList* pvl) 
		: m_board(*pb), m_visitlist(*pvl), m_font(0), m_item(-1)
	{
	}

	DECLARE_WND_SUPERCLASS(NULL, TBase::GetWndClassName())

	BOOL SubclassWindow(HWND hWnd)
	{
		ATLASSERT(m_hWnd == NULL);
		ATLASSERT(::IsWindow(hWnd));
#ifdef _DEBUG
		TCHAR szBuffer[20];
		if( ::GetClassName(hWnd, szBuffer, (sizeof(szBuffer)/sizeof(TCHAR))-1) )
			ATLASSERT(::lstrcmpi(szBuffer, TBase::GetWndClassName()) == 0);
#endif
		BOOL bRet = CWindowImpl< T, TBase, TWinTraits >::SubclassWindow(hWnd);
		if(bRet) Init();
		return bRet;
	}

	void Init()
	{
		ModifyStyle ( SS_TYPEMASK, SS_OWNERDRAW );
		CSize size(0,0);
		this->OnSize(0,size);
	}

	void Update(int item = -1)
	{
		m_item = item;
		if (item == -1)
			SetWindowTextW(m_board.Format().c_str());
		else
			SetWindowTextW(m_board.Format(-1,&m_visitlist[item]).c_str());
	}

	// Message map and handlers

	BEGIN_MSG_MAP(CBoardViewImpl)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		MSG_WM_ERASEBKGND(OnEraseBkgnd)
		MSG_WM_SIZE(OnSize)
//        MSG_WM_DRAWITEM(OnDrawItem)
//        MSG_WM_PAINT(OnPaint)
	END_MSG_MAP()

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		// First let original control initialize everything
		LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);
		Init();
		return lRet;
	}

	BOOL OnEraseBkgnd(CDCHandle dc)
	{
		SetMsgHandled(true);
		return TRUE;
	}

	void OnSize(UINT nType, CSize size)
	{
		ATLASSERT(m_hWnd);

		// Determine what font to use for the text.
		LOGFONT lf = {0};
		//			if ( !IsThemeNull() )
		//				GetThemeSysFont ( TMT_MSGBOXFONT, &lf );
		//			else
		{
			NONCLIENTMETRICS ncm = { sizeof(NONCLIENTMETRICS) };

			SystemParametersInfo ( SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, false );
			lf = ncm.lfMessageFont;
		} 

		//			lf.lfHeight = -nPos;
		if (m_font)
			m_font.DeleteObject();
		CRect rc;
		GetClientRect(rc);
		lf.lfHeight = rc.Height() / 7;
//		lf.lfWidth = rc.Width() / 7;
		m_font.CreateFontIndirect ( &lf ); 		
		//			this->Invalidate(false);
	}

	//void OnSize(UINT nType, CSize size)
	//{
	//	SetMsgHandled(false);
	//	m_boardview.OnSize(nType, size);
	//}

//	void OnDrawItem ( UINT uID, LPDRAWITEMSTRUCT lpdis )
//	void OnPaint(CDCHandle dc)
	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		T* pT = static_cast<T*>(this);
		//if( wParam != NULL )
		//{
		//	CMemoryDC memdc((HDC)wParam, NULL);
		//	pT->DoPaint(memdc.m_hDC);
		//}
		//else
		{
			RECT rc;
			::GetClientRect(pT->m_hWnd, &rc);
			CPaintDC dc(pT->m_hWnd);
			CMemoryDC memdc(dc.m_hDC, rc);
			pT->DoPaint(memdc.m_hDC,rc);
		}
		return 0;
	}

	void DoPaint(CDCHandle dc, const CRect& rcCtrl)
	{
		CString sText;

		this->GetWindowTextW( sText );

		//if ( IsCompositionEnabled() )
		//{
		//	// Set up a memory DC where we'll draw the text.
		//	CDC dcMem;

		//	dcMem.CreateCompatibleDC ( dc );
		//	dcMem.SaveDC();

		//	// Create a 32-bit bmp for use in offscreen drawing when glass is on
		//	BITMAPINFO dib = {0};
		//	CBitmap bmp;

		//	dib.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		//	dib.bmiHeader.biWidth = rcCtrl.Width();
		//	dib.bmiHeader.biHeight = -rcCtrl.Height();  // negative because DrawThemeTextEx() uses a top-down DIB
		//	dib.bmiHeader.biPlanes = 1;
		//	dib.bmiHeader.biBitCount = 32;
		//	dib.bmiHeader.biCompression = BI_RGB;

		//	bmp.CreateDIBSection ( dc, &dib, DIB_RGB_COLORS, NULL, NULL, 0 );

		//	// Set up the DC state.
		//	DTTOPTS dto = { sizeof(DTTOPTS) };

		//	dto.dwFlags = DTT_COMPOSITED|DTT_GLOWSIZE;
		//	dto.iGlowSize = 10;

		//	dcMem.SelectBitmap ( bmp );
		//	dcMem.SelectFont ( m_font );

		//	DrawThemeTextEx ( dcMem, 0, 0, CT2CW(sText), -1, uFormat, rcCtrl, &dto );

		//	dc.BitBlt ( rcCtrl.left, rcCtrl.top, rcCtrl.Width(), rcCtrl.Height(), dcMem, 0, 0, SRCCOPY );

		//	dcMem.RestoreDC(-1);
		//}
		//else
		//{
			ATLASSERT(BoardSize == sText.GetLength());
			dc.SaveDC();

			dc.FillSolidRect ( rcCtrl, GetSysColor(COLOR_3DFACE) );

			dc.SetBkMode ( TRANSPARENT );
			dc.SetTextColor ( GetSysColor(COLOR_WINDOWTEXT) );
			dc.SelectFont ( m_font );

			int xorg = rcCtrl.left;
			int yorg = rcCtrl.top;
			int width = rcCtrl.Width();
			int height = rcCtrl.Height();
			int square = 0;
			for (int y=0; y<BoardWidth; y++) 
			{
				int top = yorg + height * y / BoardWidth;
				int bottom = yorg + height * (y+1) / BoardWidth;
				for (int x=0; x<BoardWidth; x++,square++)
				{
					int left = xorg + width * x / BoardWidth;
					int right = xorg + width * (x+1) / BoardWidth;
					CRect rc(left,top,right,bottom);
					DrawChar(dc, rc, sText[square], square);
				}
			}
//			dc.DrawText ( CT2CW(sText), -1, const_cast<CRect&>(rcCtrl), uFormat );

			dc.RestoreDC(-1);
//		}
	}

	void DrawChar(CDCHandle dc, const CRect& rc, char ch, int square)
	{
		const UINT uFormat = DT_SINGLELINE|DT_CENTER|DT_VCENTER|DT_NOPREFIX;
		dc.FrameRect(rc,(HBRUSH)::GetStockObject(BLACK_BRUSH));
		const wchar_t wch = ch;
		bool found = false;
		bool draw_triangle = false;
		int direction = 4;
		if (m_item != -1)
		{
			CVisited& v = m_visitlist[m_item];
			CVisited::iterator i = std::find(v.begin(), v.end(), square);
			found = v.end() != i;
			if (found)
			{
				CVisited::iterator next = ++i;
				if (next != v.end())
				{
					int next_square = *next;
					CIndex ndx(square);
					if (ndx.isNeighbour(next_square))
					{
						draw_triangle = true;
						direction = ndx.GetNeighbourIndex(next_square);
						char s[1000];
						sprintf(s,"square=%d, next_square=%d, direction=%d\n",square,next_square,direction);
						OutputDebugStringA(s);
					}
				}
			}
		}
		COLORREF red(0x000000ff);
		COLORREF black(0x00000000);
		COLORREF clr = dc.SetTextColor(found ? red : black);
		dc.DrawText ( &wch, 1, const_cast<CRect&>(rc), uFormat );
		if (draw_triangle) DrawTriangle(dc, rc, direction);
		dc.SetTextColor(clr);
	}

	inline double Radians(double degrees)
	{
		const double pi = 3.14159265358979323846;
		return degrees / (180. / pi);
	}

	void DrawTriangle(CDCHandle dc, CRect rc, int direction)
	{
		dc.SaveDC();
		int centerX = rc.Width()/2;
		int centerY = rc.Height()/2;

		//SetGraphicsMode(dc, GM_ADVANCED);
		//XFORM xForm; 
		//double angle = 5.;
		//double radians = Radians(angle);
		//xForm.eM11 = (FLOAT) cos(radians); 
		//xForm.eM12 = (FLOAT) sin(radians); 
		//xForm.eM21 = (FLOAT) -sin(radians); 
		//xForm.eM22 = (FLOAT) cos(radians); 
		//xForm.eDx  = (FLOAT) -centerX; 
		//xForm.eDy  = (FLOAT) -centerY; 
		//SetWorldTransform(dc, &xForm); 

		CPoint edges[] = { CPoint(-1,-1),CPoint(0,-1),CPoint(1,-1), 
						  CPoint(-1,0),CPoint(0,0),CPoint(1,0), 
						  CPoint(-1,1),CPoint(0,1),CPoint(1,1) };
		CPoint triangle[] = {CPoint(-5,-5),CPoint(0,5),CPoint(5,-5)};
		int len = sizeof(triangle)/sizeof(triangle[0]);
		for (int i=0; i<len; i++)
		{
			CPoint edge = edges[direction];
			triangle[i] += rc.TopLeft() + CPoint((edge.x+1)*centerX,(edge.y+1)*centerY);
		}
		CBrush red;
		red.CreateSolidBrush(COLORREF(0x000000cc));
		CBrushHandle prevBrush = dc.SelectBrush(red);
		dc.Polygon(triangle,len);
		dc.SelectBrush(prevBrush);
		dc.RestoreDC(-1);
	}

};


class CBoardViewCtrl : public CBoardViewImpl<CBoardViewCtrl>
{
	typedef CBoardViewImpl<CBoardViewCtrl> baseClass;
public:
	CBoardViewCtrl(CBoard* pb, CVisitList* pvl) : baseClass(pb,pvl) {}
	DECLARE_WND_SUPERCLASS(_T("BoardViewCtrl"), GetWndClassName())
};

